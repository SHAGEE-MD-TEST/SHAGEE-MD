# SHAGEE-MD-V2
simple whathsapp bot created by shagee nd owner 
